0.6 入口为 dist/index.html。可直接打开，也可使用任意本地静态服务。现场函数编辑和渲染不依赖网络。预制媒体由 Showcase.zip 提供，两个压缩包解压到同一位置。editor05.html 保留历史 0.5 实验。Node 命令行渲染需要 npm install --ignore-scripts。详见 README.md。
