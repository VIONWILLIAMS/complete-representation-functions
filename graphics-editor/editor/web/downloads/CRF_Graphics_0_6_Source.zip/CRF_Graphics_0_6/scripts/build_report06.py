#!/usr/bin/env python3
"""Assemble a release report only from completed, machine-readable evidence."""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
def read(name):return json.loads((ROOT/name).read_text())
def main():
    fit=read('reports/v06/observation_fit.json');tests=read('reports/v06/tests.json');browser=read('reports/v06/browser_verification.json');video=read('reports/v06/video_verification.json')
    if not all(x['pass'] for x in [fit,tests,browser,video]):raise ValueError('Release evidence has a failed gate.')
    a,b=fit['objects'];metric_rows=[]
    for label,x in [('苹果',a),('梨子',b)]:
        metric_rows.append(f"| {label} | {x['profile']['silhouetteIoU']:.6f} | {x['profile']['initialLoss']:.8f} → {x['profile']['finalLoss']:.8f} | {x['appearance']['holdoutRgbMAE']:.5f} | {x['appearance']['constantBaselineMAE']:.5f} |")
    video_rows='\n'.join(f"| {Path(v['file']).name} | {v['width']} × {v['height']} | {v['decodedFrames']} | {v['fps']:.0f} | {v['duration']:.3f} s | 通过 |" for v in video['videos'])
    text=f'''# CRF 图形计算编辑器 0.6 · 实现与验收报告

## 交付结论

0.6 已实现一个受限但可执行的共同路径：真实照片拟合出的苹果/梨子对象与原生代码生成的对象进入同一个持久场景程序，通过同一套形状、材质、变换、可见性、相机和时间接口操作，再由同一渲染器生成像素与视频。

本次交付包括三类场景、多角度图片、共享换色/形变/遮挡示例、五秒视频、交互编辑器、离线 HTML、完整源码、模型操作指南及机器可读证据。没有以源图片作为画布背景冒充物品生成，也没有将旧版的原视角精确回放成绩挪作新版三维拟合成绩。

在线入口：https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/

## 1. 0.5 到 0.6 的实质变化

0.5 已经包含照片的密集颜色表示、局部编辑和独立程序水果，但“从图像获得的东西”和“代码生成的东西”仍容易停留在不同表示中。0.6 把共同单位提升为对象函数程序。

| 方面 | 0.6 的实际实现 | 验收方式 |
| --- | --- | --- |
| 从照片进入 | 辅助选区、颜色分割、轮廓优化、UV 颜色与置信字段 | 真实拟合误差、输入扰动、留出隔离 |
| 从代码进入 | 自定义旋转曲面、椭球、圆柱、长方体及材质函数 | 程序静物和庭院求值 |
| 共同编辑 | 同一对象 ID、shape/color/position/rotation/scale 等路径 | 两种来源逐项操作都改变真实像素 |
| 共同空间 | 透视投影、深度、遮挡和相机轨迹 | 前后关系调换、对象数组重排、新视角检查 |
| 独立重放 | 完整 JSON 携带必要字段，渲染不读取原图 | 隔离目录只放核心、渲染器和 JSON 后结果一致 |
| AI 工具 | 公共 API、五个智能体工具、编辑操作数组的原子校验 | 浏览器直接调用适配器并读回真实画布 |
| 反馈 | 真实拟合迭代、实际图像与代码检查、失败不部分提交 | 优化曲线与测试记录 |

旧版 Street、湖景与水果照片的精确回放仍保留在 `editor05.html`。本版没有声称已经将整张 Street 照片自动恢复成完整三维世界。

## 2. 共同表示如何执行

场景程序包含 `objects`、`relations`、`camera`、`light`、`environment` 和 `timeline`。一个对象由形状函数、表面外观、空间变换、来源及置信信息组成。照片拟合器输出这个对象协议；模型也可直接构造同一协议。

对每个时间点，运行时先求值轨迹，再将对象曲面采样到三维位置和法线；表面字段或程序材质给出颜色，随后进行透视投影、可见性判断与屏幕空间 Gaussian 累加。输出包括 RGBA、对象 ID、深度与置信度。背景地面使用解析光线与平面交点，是明确声明的混合渲染部分。

这里的 Gaussian 是表面采样后的投影重建核。本版没有训练各向异性三维高斯的完整优化系统，也没有把这套实现宣称为论文版 3D Gaussian Splatting 的等价实现。它首先建立了可检查的对象表示和执行接口。

## 3. 观测拟合与像素验证

源照片为 Yves Geissbühler 的 *Apple and pear*，CC0 1.0：
https://commons.wikimedia.org/wiki/File:Apple_and_pear.jpg

固定输入尺寸为 800 × 600。原照片里苹果和梨相互靠近且存在阴影，使用了明确记录的人选矩形选区，随后由颜色连通域算法提取前景。暗红边缘漏分割与梨子阴影污染在视觉检查后修正；相关选区和来源哈希记录在 `reports/v06/observation_fit.json`。

每个对象包含 32 个半径系数，随附资产使用 256 × 256 RGB 和置信度字段。运行时采用与拟合器相同的线性轮廓插值。两个对象的数值资产合计 {fit['assetFileBytes']:,} 字节。

| 对象 | 轮廓 IoU | 轮廓目标值：初始 → 最终 | 留出 RGB MAE / 255 | 平均颜色基线 MAE |
| --- | ---: | ---: | ---: | ---: |
{chr(10).join(metric_rows)}

指标含义必须保留：

- 轮廓 IoU 是拟合投影与当前提取掩膜的重合程度，不是独立人工真值测得的分割准确率，也不是完整照片的像素准确率。
- RGB MAE 按 0–255 通道值计算。留出颜色不进入系数拟合、平均颜色和背面先验；专门的扰动测试确认仅改变留出 RGB 时，输出系数不变。
- 分割与几何会用完整前景。留出实验衡量局部表面颜色插值，不衡量未知背面、未知场景或新视角的真实准确率。
- 字段分辨率比较时看过这组留出误差，所以它属于验证集，不能包装为完全独立的最终泛化测试集。
- 未拍到的背面使用低置信度镜像补全；深度、端面和旋转体结构是显式假设。

这条路径不需要“扫描仪”去恢复已经存在的图像文件 RGB；读取像素只是输入步骤。真正新增的部分是从像素约束拟合可编辑的几何和表面字段，并将误差与来源一同保存。

## 4. 视觉问题与本次修正

首轮真实渲染发现果顶横向缺环、轮廓白点、窗框和长凳薄面缺口，不能仅凭形状参数正确就通过验收。修正包括：

1. 旋转曲面沿子午线弧长采样，避免半径快速变化时相邻纬度之间空缺。
2. 分离深度遍历和 Gaussian 颜色累加，避免在遇到更近采样点时丢掉之前的有效贡献。
3. 对薄结构限制深度外推，减少边沿不连续。
4. 根据地面的像素投影足迹过滤纹理，消除木纹和砖缝的远处锯齿。
5. 对观测表面换色保留中性高光，避免逐通道倍率把高光放大成偏青亮斑。
6. 调整时间轴静态编辑按钮的位置，避免与底部状态栏重叠。

本版的物理照明能力仍有限。`observed_radiance` 保存原照片的高光和明暗；原生材质使用程序着色与近似软接触阴影。换色是可控外观编辑，不能当作已经恢复真实 BRDF 后的物理重光照。关系图可记录与校验结构，当前没有自动约束求解器。

## 5. 三个可执行场景

**共同场景。** 照片拟合苹果与程序梨进入同一坐标系。交付正面、左右、抬高、换色加形变、遮挡六张图，以及五秒运镜视频。修改观测对象时不会重新把原照片贴回画布。

**函数静物。** 苹果、梨、陶瓷花器、程序木质地面与相机组成一个纯程序案例，交付四个角度。该案例展示已有函数如何组成新画面，不依赖源照片的完整 RGB。

**午后庭院。** 墙、窗、长凳和植物由曲面与基本体组成，交付四个角度与五秒运镜视频。它是原生建筑场景实验，不是原始 Street 照片重建，也不宣称达到照片写实水平。

## 6. 实际工程验收

冻结源代码执行结果：**{tests['passed']} / {tests['total']} 项通过，{tests['failed']} 项失败**。包含旧版回归、程序协议、观测拟合与共同路径集成检查。完整 TAP 输出在 `reports/v06/tests.tap`，源码 SHA-256 在 `reports/v06/tests.json`。

真实浏览器验收：**{browser['passed']} 项通过，{browser['failed']} 项失败**。不是预先填好的状态页；由页面按钮运行操作，再读取实际 canvas 像素。验证了双来源编辑、JSON 精确重放、撤销、非法事务、实际图片重新拟合、删除后不留透明孔洞、时间轨迹与 AI 适配器的合法/非法调用。

本次浏览器没有提供 `document.modelContext`，原生 WebMCP 注册为 unavailable。已验证的是 `CRF06Agent` / `CRFEditor06` 公共接口；不能写成已验证了原生 WebMCP。支持该能力的浏览器会自动尝试注册同名工具。

程序重放与同一渲染器画布比较可达到字节一致；这证明执行确定性，不能替代与源照片的独立重建比较。本版观测拟合的 `pixelExactClaim` 为 false。

## 7. 视频验收

所有视频都实际生成后用 FFprobe 统计帧数，并用 FFmpeg 完整解码；抽查第 0、60、119 帧的解码哈希不同，确认不是静态图片重复封装。

| 文件 | 尺寸 | 解码帧数 | fps | 时长 | 完整解码 |
| --- | --- | ---: | ---: | ---: | --- |
{video_rows}

采样时间为 `i / 24`，`i = 0…119`。渲染耗时不改变成片时间。浏览器视频默认 640 宽，固定五秒；自定义长短轨迹会归一到五秒。CLI `--duration` 按实际场景秒数采样。当前预设均为五秒轨迹。

视频是有损编码，静态严格像素检查应使用原始 PNG 或 RGBA。CPU 预览和离线导出已验证，本版不宣称 GPU 性能或 60 fps 实时渲染。

## 8. LLM 如何操作

模型先读取当前 JSON 与能力清单，再把语言意图转为完整程序或原子操作数组。可调用 `crf_read_scene`、`crf_apply_operations`、`crf_set_program`、`crf_render_view`、`crf_undo`。这些工具执行与界面相同的校验和渲染；复杂物体由新的几何、材质和字段程序来表达。

顶部输入框是有限规则编译器，没有接远端模型。未知“生成汽车”会明确未识别并保留当前场景，资产载入不会伪装成理解了用户意图；对已有观测对象的编辑也不会被默认资产覆盖。完整接口、运行命令和示例在 `docs/v06/LLM_GUIDE.md`。

这仍只是终极需求的一段可执行基础。若要达到“任意语言生成高质量照片与视频”，还需要更丰富的物品函数、结构与材质先验、可靠的观测反演、复杂时空生成、更快的执行器，以及固定任务集上的质量比较。Fable 5.2 是目标参照，本版没有进行同题盲测，也不宣称已达到其水平。

## 9. 反馈改进的范围

拟合器确实优化轮廓和颜色字段，测试也会根据实际失败修正实现。本次保留了真实的损失曲线、留出隔离证据、画布验收和源代码哈希。它还不是自主递归改写任意管线的通用 RSI 系统；没有证明每轮修改一定提高所有画面的质量。

下一阶段应在共同协议上补足“物品函数生成与反演”的能力：引入新的物品家族、多视图约束、可分离材质与照明、持久运动，以及可跨场景检验的验收数据。这样扩展的是同一个运行系统，而不会再次将图像路径和程序路径拆成互不相通的两套演示。

## 10. 复现入口

```sh
npm install --ignore-scripts
node scripts/build_observations06.cjs
node scripts/check_v06.cjs
node scripts/run_program06.cjs --preset common --output common.png
node scripts/run_program06.cjs --program scene.json --sequence frames --fps 24 --duration 5
```

`dist/downloads/manifest-v06.json` 列出真实文件大小与 SHA-256。源码包与媒体包使用同一目录根；单文件编辑器可直接运行。浏览器测试与媒体验收结果必须通过实际执行重新取得，打包脚本不会补造结果。
'''
    (ROOT/'docs/v06/REPORT.md').write_text(text)
    print('Wrote docs/v06/REPORT.md from completed evidence')
if __name__=='__main__':main()
