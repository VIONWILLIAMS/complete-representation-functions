# CRF 图形计算编辑器 0.9 · 离线重绘包

包含真实 DeepSeek 编辑器任务的场景程序、每个场景的精确共享模型快照、成图、来源/调用记录、原街景高斯依赖，以及与编辑器相同的求值器。没有 API 密钥，也不需要联网调用模型即可重绘。

**当前为开发候选。可执行和像素一致性不代表照片级质量验收通过。** 查看索引中每个任务的状态及包内验收记录。失败任务仍保留在索引和统计中。

## 运行要求

Node.js 20 或更新版本。PNG 编码只使用 Node 内置 zlib，不需要 npm install。

```sh
node scripts/render_v09.cjs web/assets/v09/generated/showcase-v1/01_ivory_facade.scene.json output.png
node scripts/render_v09.cjs --all web/assets/v09/generated/index.json outputs
node scripts/render_v09.cjs scenes/street_original.json street.png
node scripts/render_v09.cjs scenes/street_blue.json street-blue.png
node scripts/render_v09.cjs scenes/street_signal_removed.json street-removed.png
node scripts/render_candidates09.cjs CANDIDATES.json candidate_outputs
```

`web/assets/v09/generated/index.json` 保留全部真实任务。每个生成场景可以由另一个 LLM 修改语义对象、颜色、形态、位置、灯光和相机，然后重新执行。新对象类别需要实际实现对应函数，不可仅写一个名称来假定生成能力存在。

`CANDIDATES.json` 另保留全部实际候选的重绘索引。候选目录包含各自的精确场景／模型快照、JPEG预览、`record.json` 和 `task_evidence.json`；为控制包体，不重复存放候选PNG。上述候选重绘命令会检查实际渲染RGBA是否与原任务记录的哈希一致。预览JPEG为有损图，不作为像素一致性的目标。

## 左、中、右和 5 秒运镜

```sh
node scripts/render_v09.cjs --views web/assets/v09/generated/showcase-v1/01_ivory_facade.scene.json views
node scripts/render_v09.cjs --frames web/assets/v09/generated/showcase-v1/01_ivory_facade.scene.json frames --fps 24 --duration 5 --width 1920 --height 1080
ffmpeg -framerate 24 -i frames/%04d.png -frames:v 120 -vf "scale=in_range=full:out_range=limited:out_color_matrix=bt709,format=yuv420p,setparams=range=limited:color_primaries=bt709:color_trc=iec61966-2-1:colorspace=bt709" -c:v libx264 -preset medium -crf 21 -maxrate 4M -bufsize 8M -pix_fmt yuv420p -color_range tv -colorspace bt709 -color_primaries bt709 -color_trc iec61966-2-1 -movflags +faststart video.mp4
node --test tests/test_media09.cjs
```

逐帧模式输出120张实际渲染 PNG 与 `trajectory.json`，共5秒、24 FPS。视频容器为1920×1080；本版4:3场景以1440×1080原生求值，置于x=240、y=0，左右填充不透明纯黑，保留物体比例，不拉伸或裁切内容。每帧报告记录实际viewport。相机路径与编辑器一致：`u=t/5; s=u*u*(3-2*u); panX+=.056*s; panY-=.008*s; zoom*=1+.065*s`，左右视图偏移±.042，保留原场景相机。帧 i 的时间为 i/24秒。ffmpeg 仅是可选的外部视频编码器，图片求值器不依赖它。

生成场景的视角是声明范围内的图像平面深度视差与解析推断，未验证为真实世界多视角重建。原街景视角变化是二维图像平面裁切，不能算3D。街景非正面裁切使用确定性CPU双线性采样，浏览器Canvas插值可能有细微差异；正面原尺寸的像素核验单独进行。

MP4使用有损H.264编码，不宣称与源帧逐像素一致。编码显式执行全范围RGB到有限范围BT.709 YCbCr转换，并保留sRGB传递函数标记；`setparams`把颜色信息写入实际帧属性。媒体报告包含ffprobe颜色标签和解码首帧相对源帧内容区的MAE/RMSE，避免仅以帧数作为验收。

## 表示与数据

- 新生成：解析图像平面结构、共享线性照明、采样高斯场、真实学习的高斯系数均值/PCA。渲染器不读取原始照片或贴图。
- 原街景：0.8观测高斯场加显式披露的观测细节系数；严格复现依赖这些已知信息。删除后的墙面由可见语境推断，隐藏真实背景未知。
- 每个生成程序内嵌其确切 `appearanceModel`，优先于工作台后续更新的共享模型，避免重新打开时悄悄改变画面。

`MANIFEST.json` 记录文件大小与SHA-256；`VERIFICATION.json` 记录独立目录解包后的逐项RGB/RGBA核验，失败不会被省略。包内没有Git元数据、运行凭据或训练原图。
