打开 dist/index.html 可使用四个案例。预制图库和视频位于配套 Showcase.zip；两个包解压到同一目录可合并。完整源码、参考PNG、数值数据、原始两张CC0图片、扫描/渲染/验收脚本均在本包。需要本地HTTP时运行 python3 -m http.server 4173 --directory dist。
