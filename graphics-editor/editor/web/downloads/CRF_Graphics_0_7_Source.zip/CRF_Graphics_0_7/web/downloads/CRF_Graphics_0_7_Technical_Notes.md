# CRF 图形计算编辑器 0.7 · 共同路径与验收边界

> 下载版链接说明：本文件的资源链接指向已发布站点。标注“源码包内”的链接下载 [完整源码包](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_7_Source.zip)，解压后在 `CRF_Graphics_0_7/` 下按所列路径查找；离线阅读请使用包内 `docs/v07/TECHNICAL_NOTES.md`。


0.7把共同路径落实为：**把观察或语言意图组织成可编辑的物品函数，由受控执行器计算像素，再把实际结果送入有证据的检查与修正流程。** 早期街景、高斯观测、照片拟合和新增原生场景都保留在同一个工作台中。当前有多种场景协议与执行器，不能把界面整合解释成已经完成了所有数据模型与光传输器的统一。

本文说明当前实现、已有证据和仍需验证的能力，不预填本次新生成图片的最终质量验收结论。实际程序、原始请求记录、生成图片与反馈前后对照应一起检查。

## 1. 共同的单位是可求值对象

可以用下面的概念接口解释三代实现：

\[
F_i=\bigl(G_i,A_i,T_i,V_i,P_i\bigr),\qquad
I_t=E\bigl(\{F_i\},C_t,L_t,D,q\bigr).
\]

这里，\(G_i\) 是几何或观测表面，\(A_i\) 是表面颜色或材质函数，\(T_i\) 是空间变换，\(V_i\) 是可见性，\(P_i\) 是来源与置信信息；\(C_t\)、\(L_t\) 是相机和光照状态，\(D\) 是执行时需要的数值资源，\(q\) 是分辨率、采样、降噪等实际设置。执行器 \(E\) 生成像素、对象归属和深度等结果。

这是一种说明接口关系的形式，并非宣称这些字母已经是某个JSON协议的实际字段。0.5、0.6、0.7的具体协议、坐标单位和能力不同，工作台按 `engine` 调用对应运行时。[实现：工作台说明](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_7_Editor.md)、[0.6对象协议](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_7_Source.zip)（源码包内：`docs/v06/PROGRAM_SCHEMA.md`）、[0.7图像程序](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_7_Radiance_Schema.md)。

它对用户目标的价值在于：同一个对象拥有稳定ID，可以修改函数、参数和组合关系；编辑后的像素来自重新求值。语言模型操作的是这些可检查的表示，不需要替用户手工操作大量底层像素，也不需要直接执行任意生成脚本。

必须显式保留 \(D\)。在观测路径中，RGB系数就是输入照片的信息载荷；不能因为读取这些系数的代码很短，就声称模型从很少信息重新发明了整张照片。在原生路径中，载荷主要是几何、材质、灯光、相机和种子，细节由程序函数和求值过程产生。两种来源对“复现”的含义不同。

## 2. 三条已存在的执行路径

| 路径 | 实际表示与求值 | 已有用途 | 需要保留的边界 |
|---|---|---|---|
| `legacy05` | 逐像素RGB观测系数、语义标签、推断的分层深度、对象变换与有限支持高斯累加。 | 红绿灯Street、果园、山湖等原视角复现、局部换色、背景补齐和有限视角编辑。 | 存储了原始观测颜色；深度和隐藏部分含假设。原视角精确复现不证明恢复了真实完整三维。 |
| `program06` | 对象曲面、观测UV颜色/置信字段或程序材质；共同的曲面采样、透视投影、深度判断与高斯累加。 | 照片拟合苹果/梨子与原生对象共处、共同编辑、遮挡、相机轨迹与既有视频案例。 | 对果体做了限定类别的拟合；存在辅助选区、旋转体与背面先验。光照、阴影是明确的近似。 |
| `radiance07` | `crf.image_program.v0.7`中的几何、材质、面积光、环境和镜头；直接计算交点、可见性、光照、反射、折射和程序表面颜色。 | 模型编写新场景程序，逐对象编辑，实际画面反馈与重新渲染。 | 当前受限于四种几何原语、限定材质函数与运行预算。视觉质量要逐场景检查。 |

相关实现分别位于 [crf-core.js](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/crf-core.js)、[crf-program.js](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/crf-program.js)、[crf-program-renderer.js](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/crf-program-renderer.js)、[crf-radiance07.js](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/crf-radiance07.js)。

0.6已经提供了一个真实的共同执行器：观测拟合对象和程序对象进入同一个场景，再走同一条表面高斯渲染路径。0.7增加光线求值执行器，是为了补足新生成场景的材质、照明、遮挡与反射/折射表达，同时继续保留旧案例与旧工具。**目前尚未把任意0.5密集观测对象直接转换为0.7可重光照材质。** 这项转换还需要解决表面、材质、光照和遮挡的辨识问题。[0.6实际实现与限制](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_6_Report.md)。

因此，“共同路径”已经存在于对象编辑和受控求值的组织方式中；完全统一的场景编译器仍是进一步的工程目标。当前实现没有证明一个受限的几何与函数语法可以表达所有可能的自然图像。

## 3. 搜索参考如何进入原生图像程序

新增链路由 `server/deepseek07.mjs`、`server/references07.mjs`、Worker路由、编辑器和渲染器共同完成。

1. **语言意图。** 输入场景目标、对话历史和需要保留的当前对象结构。新生成进入0.7引擎；对旧案例的编辑保留旧引擎和对象ID。
2. **实际搜索。** DeepSeek聊天请求声明官方 `deepseek_web_search` / `deepseek_read_url` 工具。只有观察到完成的搜索调用，或独立搜索API实际返回，才记录 `searched:true`。模型自己说“我已经搜索”不算证据。[官方Web Tools](https://api-docs.deepseek.com/guides/web_tools/)、[官方Search API](https://api-docs.deepseek.com/guides/search/)。
3. **实际参考图像。** 采集器从允许的公开照片页面读取图像元数据，获取允许的图像主机上的字节，记录来源、尺寸、MIME、SHA-256与失败原因。当前检查包含PNG/JPEG/WebP容器结构与尺寸边界，不宣称完成了所有编码流的完整图像解码。页面401/403不会被绕过。视频页面的封面如果被用作参考，应按实际来源记录，不能抹掉其视频页面来源。
4. **图像理解与函数提议。** 已取得的参考图作为真实 `image_url` 输入交给 `deepseek-flash`，同时提供文字资料。模型需要综合主体形态、组合结构、材质细节、镜头与光照，返回完整的场景JSON和限定数学表达式。[官方视觉接口](https://api-docs.deepseek.com/guides/vision/)、[模型能力列表](https://api-docs.deepseek.com/api/list-models/)。
5. **协议校验与像素生成。** JSON经过协议、预算与执行器校验，编辑器先渲染候选，再决定能否替换当前场景。参考照片字节不进入0.7的程序材质；0.7渲染器不通过读取这些照片来拼成新场景。
6. **反馈。** 编辑器可以把刚刚渲染的实际画面与程序再次提交模型，得到修改后的候选，并保留初稿与反馈后的对照。

官方Web Tools不能和非文本 `response_format` 共用同一次请求，因此资料研究和JSON程序生成分成两个阶段。第二阶段使用JSON模式后，仍然可能出现格式或语义错误；本地验证不可省略。[官方Web Tools限制](https://api-docs.deepseek.com/guides/web_tools/)、[官方JSON模式](https://api-docs.deepseek.com/guides/json_mode/)。

服务分别记录网页来源数、候选页面数、实际尝试页面数、取得图像数和成功提交视觉模型的图像数。它们不是同一个数量。参考图最多选8张；当前Worker采集默认上限为6张，不能描述成每次已经学习了几十张照片。

“参考图 → 模型提出函数”是**带图像上下文的程序合成**。本版本没有更新DeepSeek的模型权重，也没有把这些网页照片变成训练数据集再训练一个图像生成模型。0.6里的数值拟合则是另一种明确存在的操作：用指定对象的像素误差调整形状或颜色字段，并记录损失曲线。两者应分别命名和验收。[0.6观测拟合说明](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_7_Source.zip)（源码包内：`docs/v06/OBSERVATION.md`）、[0.7接口实现说明](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_7_DeepSeek_API.md)。

## 4. 函数、材质与物理含义

0.7使用 `ellipsoid`、`box`、`cylinder`、`lathe` 组合物品。旋转曲面可以表达花器和果体轮廓，长方体可以声明有限倒角。对象空间以局部底部 `y=0` 为基准，变换使用位置、角度和缩放。

材质函数是白名单数学表达式树：常量、坐标、噪声、分形噪声、Voronoi、加法、乘法、正弦、绝对值和截断。`add` / `mul` 支持2–8项，按左到右顺序求值；每个材质最多96节点、深度12。函数输出作为颜色调制量，范围限制为0–2。它目前不是可以修改任意几何、散射过程或执行任意代码的通用语言。[实际语法与预算](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_7_Radiance_Schema.md)。

现有执行器确实计算几何交点、遮挡、面积光采样、反射和折射，材质透射也不是简单降低二维alpha。不过算法与采样预算包含交互取舍，不等于已经验证了所有材质的物理精度。降噪是单独的、可见的显示/输出选项，应和分辨率、样本数、种子一起记录。

观察到的颜色与可重光照材质必须区分。照片里的RGB已经包含原拍摄的光照、阴影、高光、曝光等成分。把它附着在曲面上可以得到可编辑外观，但不能自动得到唯一的反射率、粗糙度、光源和真实深度。对于单图未显示的背面，也只能选择明确的假设或取得额外观察证据。

这说明像素路径与生成路径真正继续融合时需要补什么：对象表示应能够区分观测辐射、几何假设、材质参数和未知区域，并用独立的多视角或光照证据约束它们。当前代码已经提供部分表示与接口，不能用一次正面像素匹配代替这些额外约束。

## 5. 三种像素成绩必须分开

| 检查 | 比较对象 | 能说明什么 | 不能说明什么 |
|---|---|---|---|
| 原视角观测回放 | 独立解码的冻结参考PNG与实际画布RGB。 | 密集观测系数及求值路径是否准确复现已存储的采样。 | 没有证明压缩、未知视角正确性或从语言创造同一张照片。 |
| 程序重放 | 同一程序、执行器、种子、采样、降噪设置下的两个实际结果。 | 程序与运行设置是否可复现，导入导出是否保真。 | 确定性的结果仍然可能不真实、不符合用户意图。 |
| 生成图质量 | 目标描述、独立照片/视角证据、实际生成图与明示评价规则。 | 物品是否正确，结构接触、材质、照明、细节和构图是否达标。 | 不能用输出文件存在或JSON校验通过代替视觉验收。 |

原视角RGB比较采用明确的像素网格。例如：

\[
\mathrm{MAE}=\frac{1}{3WH}\sum_{x,y,c}|I_{xyc}-R_{xyc}|,
\qquad
\mathrm{ExactPixels}=\sum_{x,y}\mathbf{1}[I_{xy}=R_{xy}].
\]

严格100%要求尺寸相同、每个像素的RGB三个通道全部相等。比较阶段不通过重新缩放、配准、模糊或颜色容差制造成功。历史0.5报告已明确：这一结果在冻结参考尺寸上成立，密集RGB仍被保存；新增照片在冻结前做过的方向与尺寸处理也有记录。[0.5验收报告](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_5_Report.md)、[机器可读验收](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_7_Source.zip)（源码包内：`reports/v05/acceptance.json`）。

该观测模式的精确性来自具体实现：原采样中心使用有限支持高斯核，支持半径小于相邻像素中心间距，归一化后可以恢复原RGB。离开原视角后需要更宽的核、深度假设和遮挡处理，因此原视角的等值证明不能直接延伸到新视角。[旧观测执行器说明](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_7_Source.zip)（源码包内：`docs/ENGINE.md`）。

换色、移物或增加光源之后，相较原图的MAE通常会增大，这是预期的编辑差异；它不是“质量下降”的自动判据。0.7的前后对照把MAE和改变像素比例标为差异，不把它们包装成写实评分。要判断编辑是否成功，应同时检查用户指定变化是否发生、其他区域是否被意外破坏、边缘与遮挡是否合理。[工作台对照行为](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_7_Editor.md)。

新视角没有独立实拍参考时，只能评估可见的结构与时序一致性，不能标记为真实世界100%复刻。同样，视频文件存在不代表完成了时空场景恢复；历史视频的帧数、时长和解码验证与新增场景的质量验证应分别保留。[历史视频验收范围](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_6_Report.md)。

## 6. 已发生的多层反馈

本次已经遇到真实的接口、表示和画面问题，修正层次不同。

**程序格式与参数层。** 实际模型输出出现材质字段兼容和JSON语法问题。服务按渲染器真实协议接受合法可选材质字段，并把具体对象/字段错误反馈给模型。自动协议或语法修正最多一次；原始候选、修正请求和用量分开保存。它不静默钳制数值或改写用户程序。[服务实现](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_7_Source.zip)（源码包内：`server/deepseek07.mjs`）、[服务测试](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_7_Source.zip)（源码包内：`tests/test_deepseek07.mjs`）。

**表示能力层。** 实际模型候选经常用3–5项加法/乘法表达材质。早期协议只允许二元运算，产生了不必要的拒绝。当前执行器和服务一起扩展到2–8项，保留节点/深度预算和明确的左折叠顺序；原候选的表达式不必被更改。原始诊断记录保留在 `reports/v07/diagnostic_*` 中，恢复这类候选时应标记是执行器表示扩展，不伪造一次新的模型调用。

**实际画面层。** 已查看的室内初稿存在明显墙体空隙、悬空桌腿和过亮光板。对应的程序错误包括把以底部为原点的对象当作以中心为原点：高3米的墙设置 `position.y=1.5`，高0.44米的腿设置 `position.y=0.22`。正确接触需要使用地面顶面高度，桌板底部再接到桌腿顶部。系统协议已加入具体数值例子，并说明面积光源本身会被镜头看见，需要安排在视锥外或合理的窗/灯位置。提示修改不是已经修好所有画面的证据，仍要看后续真实渲染。[室内初稿程序](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/assets/v07/generated/interior_initial.crf.json)。

**采集与集成层。** 注入式网络测试复现了取消信号未阻止继续下载、仅4字节PNG前缀被误认作可用图像、候选页面数被当作实际尝试数的问题。根模块随后修复取消传播、容器/尺寸检查和计数。Worker也统一了状态页面报告的模型与实际固定模型，并验证了静态资源绑定、6MiB流式请求上限与凭据不回传。[采集器](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_7_Source.zip)（源码包内：`server/references07.mjs`）、[Worker](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_7_Source.zip)（源码包内：`server/worker07.mjs`）、[针对性回归](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_7_Source.zip)（源码包内：`tests/test_worker_references07.mjs`）。

这些事实构成了有限的多层工程反馈：模型候选、程序协议、执行器和采集管线都能根据真实错误改进。当前并没有一个会自主改写所有管线、自动证明质量单调提升的通用递归自改进系统。用户提出的多级RSI目标可以据此继续构建，但每一层都需要自己的证据、预算和回退条件。

## 7. 当前可核验的证据与后续质量判断

本说明编写时，已实际运行的服务及集成测试为 **32/32通过**：23项Provider回归和9项Worker/参考采集回归。它们使用注入的模拟网络和测试令牌，不等于真实模型生成质量的通过成绩。执行命令为：

```bash
node --test tests/test_deepseek07.mjs tests/test_worker_references07.mjs
```

保存的实际搜索响应通过解析器验证出了完成的原生搜索调用、7个查询和15个去重后的来源；该数字只属于那次保存的请求。参考采集记录另外列出每个来源实际取得或失败的情况。[搜索原始证据](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_7_Source.zip)（源码包内：`reports/v07/search_probe.json`）、[参考采集证据](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_7_Source.zip)（源码包内：`reports/v07/reference_collection.json`）。

整体验收应把以下材料同时保留：用户原始意图、实际模型与请求ID、实际搜索和参考图记录、模型原始候选、执行器版本、最终提交程序、采样/降噪设置、初稿和反馈后的图像，以及失败或回退说明。对用户指定旗舰模型水平的比较还需要同题对照和独立评价；本说明没有给出这样的等价结论。

后续的进步应体现在可见结果上：更多场景能正确构造，物品接触不再悬空，边缘与材质更可信，光照与反射更合理，同一物品在编辑和变换后保持一致。对应函数、程序与管线的改动必须可追踪。这个标准比把所有图片泛称为“代码生成”更具体，也使CRF能够逐步接近用户要求的高质量图像与视频生成能力。
