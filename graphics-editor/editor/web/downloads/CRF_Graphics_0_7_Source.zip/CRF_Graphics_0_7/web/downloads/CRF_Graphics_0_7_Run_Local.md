# CRF 图形计算编辑器 0.7：本地运行

> 下载版链接说明：本文件的资源链接指向已发布站点。标注“源码包内”的链接下载 [完整源码包](https://crf-street-04-lab-4d86.laterafter950.chatgpt.site/downloads/CRF_Graphics_0_7_Source.zip)，解压后在 `CRF_Graphics_0_7/` 下按所列路径查找；离线阅读请使用包内 `docs/v07/RUN_LOCAL.md`。


本地编辑器使用同一个 HTTP 服务提供场景资源与模型接口。默认地址是 **http://127.0.0.1:4173**。

## 1. 准备工程

安装 Node.js 20 或更新版本及随附的 npm。解压 `CRF_Graphics_0_7_Source.zip`，进入顶层 `CRF_Graphics_0_7` 文件夹。

如果同时下载了 `CRF_Graphics_0_7_Images.zip`，将它解压到同一位置，合并同名的 `CRF_Graphics_0_7` 文件夹及其中的 `web/`、`reports/`。这样“模型实测对比”中的实际渲染图、生成程序和执行记录也可在本地查看。不要将 Images 包解压进构建目录 `dist/`。

工程中的 `web/` 保存编辑器、场景、参考像素数据和媒体的源文件；`server/` 保存模型接口，`scripts/` 保存构建与检查程序。`dist/` 仅保存构建产物，源码包不包含这个目录。

在工程目录运行：

```bash
npm install
npm run dev
```

浏览器打开：

```text
http://127.0.0.1:4173
```

端口可以显式指定：

```bash
npm run dev -- --host 127.0.0.1 --port 4173
```

服务运行期间保持终端打开。结束时在该终端按 `Ctrl+C`。

## 2. 先使用本地场景

没有模型 API 密钥时，编辑器会如实显示接口未配置。以下本地操作仍然可用：

- 打开红绿灯 Street、苹果与梨子、实拍水果、湖畔，以及全部 0.6 案例。
- 编辑已有对象、材质、相机、函数与 JSON，并查看旧案例保留的视角和视频工具。
- 运行 0.7 原生图像场景，换色、改变粗糙度与曝光，重新计算画面。
- 导出当前 PNG、场景 JSON，以及使用原案例编辑器的视频导出功能。
- 打开 `http://127.0.0.1:4173/verify-v07.html`，点击运行本地浏览器验收。

0.7 主入口源文件为 `web/index.html`；开发服务将 `web/` 作为静态根目录。网页 URL 保持原样，例如 `/index.html`、`/assets/v07/experiments.json`、`/downloads/manifest-v07.json`，不增加 `/web` 前缀。请通过上述 HTTP 地址访问，以便加载资源、执行相对地址请求和使用模型接口。

源码保留已有照片案例的完整观测数据、RGB 系数与原编辑器，也包含七个旧案例的正面参考 PNG：Street、苹果与梨子、实拍水果、湖畔及 0.6 三个案例。它们供侧栏缩略图、正面展示和独立参考比较使用；Street 的 0.4、0.5 验收候选 PNG 与原始 `assets/reference.png` 同时保留。因此，仅解压 Source 包即可显示这些缩略图并进行初始 Street 像素验收。

旧版完整独立画布验收入口为 `http://127.0.0.1:4173/verify-v05.html`，它载入保留的 `editor05.html`；0.7 工作台验收仍在 `verify-v07.html`。旧版额外视角的预制图片、运镜视频和单文件交付继续由原版媒体包提供；本次 Images 包收录 0.7 实际模型结果。既有场景仍可在本地重新计算视角或导出视频。

## 3. 连接自己的 DeepSeek 测试接口

先结束正在运行的开发服务，再在 **Bash 终端**运行以下命令。第一行输入的密钥不会回显，也不会作为命令文本写入 shell 历史；密钥只作为这次服务进程的环境变量传入。

```bash
read -r -s -p "DeepSeek API key: " CRF_DEEPSEEK_KEY
printf '\n'
DEEPSEEK_API_KEY="$CRF_DEEPSEEK_KEY" npm run dev -- --host 127.0.0.1 --port 4173
unset CRF_DEEPSEEK_KEY
```

随后刷新页面。默认模型名由当前服务端适配器设置为 `deepseek-flash`。服务端读取 `DEEPSEEK_API_KEY`，前端没有密钥输入框，也不会把它写入场景 JSON 或浏览器草稿。

API 配置存在与真实调用成功分别显示。执行“生成新图片”后，参考区会展示本次实际返回的搜索来源、参考照片获取记录和视觉提交数量。“检查当前画面”提交实际渲染图取得意见；“检查并改进”请求一次修改。新图生成默认另做一轮可关闭的实际画面反馈。

密钥能力、可用模型、联网搜索和图像输入以所连接接口的真实响应为准。当前适配器及请求格式见 `docs/v07/DEEPSEEK_API.md`。程序渲染和模型调用是两个独立步骤；调用成功不代表已经达到照片级画质。

## 4. 修改与保存作品

每个场景可分别保存浏览器草稿。重要作品请同时导出 PNG 和场景 JSON。0.7 导出的 JSON 带有引擎、场景程序和实际渲染设置，可由另一个模型继续生成受约束的程序或操作数组。

快速预览使用较低分辨率和采样。完成构图后，可提高尺寸和采样并重新渲染。勾选“降噪显示”会运行显式降噪处理，界面和导出设置均会记录。CPU 渲染耗时随场景复杂度、像素数与采样数增加，任务可以停止；停止时保留此前已完成的画面。

详细接口与场景格式：

- `docs/v07/EDITOR.md`
- `docs/v07/RADIANCE_SCHEMA.md`
- `docs/v07/DEEPSEEK_API.md`

## 5. 构建与重新打包

安装依赖后可构建服务器与静态资源：

```bash
npm run build
```

构建程序从 `web/` 读取静态资源，输出到 `dist/client`；服务器输出到 `dist/server`，相关构建配置也在 `dist/` 内。`dist/` 不再同时保存一套页面源文件，避免部署归档重复包含所有媒体。源码包内 `.openai/hosting.json` 是可移植的空配置，使构建脚本能够运行；它没有包含原站项目身份。要发布到 Sites，需要独立注册或选择你的项目身份并按相应发布流程配置，这不影响本地运行。

安装 Python 3 后，在工程目录执行：

```bash
python scripts/package_v07.py
```

脚本在 `web/downloads/` 生成 Source、Images 两个 ZIP 和 `manifest-v07.json`，只列出实际存在的交付文件，并计算字节数与 SHA-256。两个包使用相同顶层目录，保留 `web/`、`reports/` 等源码路径，不包含 `dist/`。每个压缩包执行 CRC 检查，且必须小于 24 MiB。旧版压缩包和媒体不会被删除；新增图片、程序或报告后重新执行即可更新本次交付。

模型结果源文件在 `web/media/v07/`，生成程序在 `web/assets/v07/generated/`，实测索引在 `web/assets/v07/experiments.json`。修改或重新打包后再次运行 `npm run build`，使新的交付文件进入 `dist/client/`；公开下载 URL 仍是 `/downloads/文件名`。

源代码包排除依赖目录、构建产物、原项目身份、临时密钥和本次网络参考图的输入字节。实际 API 候选文本、搜索来源、提交记录与既有像素系数保留。ZIP 完整性、可运行检查和画布差异分别记录，不作为照片真实性的自动评分。
