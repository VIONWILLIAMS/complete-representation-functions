#!/usr/bin/env node
'use strict';
// Authored assets live in web/. Build one static copy and a self-contained Worker.
const fs=require('node:fs'),path=require('node:path'),esbuild=require('esbuild');
const root=path.resolve(__dirname,'..'),dist=path.join(root,'dist'),web=path.join(root,'web');
async function main(){
 const hosting=JSON.parse(fs.readFileSync(path.join(root,'.openai/hosting.json'),'utf8'));
 if(hosting.static)throw new Error('Worker source manifest must omit static.');
 if(!fs.statSync(path.join(web,'index.html'),{throwIfNoEntry:false})?.isFile())throw new Error('Authored web/index.html is missing; refusing to replace build output.');
 const client=path.join(dist,'client'),server=path.join(dist,'server');
 fs.rmSync(dist,{recursive:true,force:true});fs.mkdirSync(server,{recursive:true});
 fs.cpSync(web,client,{recursive:true});
 await esbuild.build({entryPoints:[path.join(root,'server/worker07.mjs')],outfile:path.join(server,'index.js'),bundle:true,format:'esm',platform:'browser',target:'es2022',minify:false,logLevel:'warning'});
 fs.mkdirSync(path.join(dist,'.openai'),{recursive:true});fs.writeFileSync(path.join(dist,'.openai/hosting.json'),JSON.stringify(hosting,null,2)+'\n');
 fs.writeFileSync(path.join(server,'wrangler.json'),JSON.stringify({name:'crf-graphics-editor',main:'index.js',compatibility_date:'2026-05-15',assets:{directory:'../client',binding:'ASSETS',run_worker_first:['/api/*']}} ,null,2)+'\n');
 const source=fs.readFileSync(path.join(server,'index.js'),'utf8');const worker=await import('data:text/javascript;base64,'+Buffer.from(source).toString('base64'));
 if(typeof worker.default?.fetch!=='function')throw new Error('Invalid Worker export');
 const status=await worker.default.fetch(new Request('https://example.test/api/crf/status'),{});if(status.status!==200||JSON.parse(await status.text()).configured!==false)throw new Error('Invalid configuration boundary');
 const staticResult=await worker.default.fetch(new Request('https://example.test/'),{ASSETS:{fetch:async()=>new Response('asset')}});if(await staticResult.text()!=='asset')throw new Error('Static assets not preserved');
 console.log(JSON.stringify({workerBytes:Buffer.byteLength(source),staticRoot:'dist/client',status:'ready'},null,2));
}
main().catch(error=>{console.error(error.message);process.exitCode=1;});
