# CRF 图形计算编辑器 0.7

运行步骤见 docs/v07/RUN_LOCAL.md。先执行 npm install，再执行 npm run dev，打开 http://127.0.0.1:4173。

页面、案例与媒体的源文件在 web/；dist/ 仅存放重新构建的 client/、server/ 和构建配置，不进入源码包。浏览器 URL 仍从根路径访问，不增加 /web 前缀。

本地案例和程序渲染不需要 API。模型对话需要自行提供运行时密钥。源码不包含原站项目身份或密钥；.openai/hosting.json 是可移植空配置。

Images.zip 与 Source.zip 使用相同顶层目录 CRF_Graphics_0_7，解压到同一位置并合并 web/、reports/，即可加入本次实际图片、程序和执行记录。既有照片案例的观测数据、全部编辑器与生成引擎已保留。源码含七个旧案例的正面参考缩略图，以及独立 Street 像素验收所需参考 PNG。额外历史视角图与预制视频继续由原版媒体包提供。
