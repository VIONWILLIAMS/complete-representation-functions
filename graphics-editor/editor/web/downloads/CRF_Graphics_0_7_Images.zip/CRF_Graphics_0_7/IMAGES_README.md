# CRF 0.7 实际模型结果

包含本次实际生成的图片、对应场景程序与经清理的执行证据。初稿和反馈后并列，不自动判定质量高低。

与 Source.zip 解压到同一位置，合并 CRF_Graphics_0_7 内的 web/、reports/ 文件夹。实际媒体位于 web/media/v07/，生成程序位于 web/assets/v07/generated/，编辑器中的“模型实测对比”读取 web/assets/v07/experiments.json。网页 URL 仍为 assets/v07/experiments.json，不增加 /web 前缀。未完成的轮次不会用其他图片代替。

网络参考图片的输入字节不分发；来源、获取状态、实际提交记录和模型候选文本保留。照片级真实性需要独立评估，打包校验仅验证文件完整性。
