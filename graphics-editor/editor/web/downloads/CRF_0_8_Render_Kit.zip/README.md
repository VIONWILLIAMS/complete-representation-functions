# CRF 0.8 · 六组作品离线重绘包

这里包含六份实际 DeepSeek 场景程序、它们引用的高斯函数、共享渲染器、结果 PNG、拟合与调用记录。它是独立渲染实验包，不包含托管编辑器的全部界面和历史媒体；完整编辑器及原有案例在已发布的网站中保留。

## 无需调用模型即可重绘

```sh
npm install
node scripts/render_v08.cjs scenes/01_ceramic_citrus.json output.png
node scripts/render_v08.cjs scenes/street_full_benchmark.json street.png web/assets/reference.png
```

场景 JSON 可直接由另一个 LLM 修改。更改对象 x/y、scaleX/scaleY、hue、exposure、opacity、visible 或 zIndex，再用同一命令计算像素。新增 assetId 必须先有对应高斯函数；不能把目录中没有的物体名称当成已实现的图像生成能力。

RGB 由二维高斯系数求值，渲染时不读取参考图片；第三个参数只用于误差比较。alpha 为单独保存的观测覆盖率。不同来源的光照尚未统一分解，新构图仍可能有拼合感。

`MANIFEST.json` 提供每个文件的 SHA-256。六张成品位于 images/，完整程序位于 scenes/。不含 API 密钥。独立图像拟合脚本需要 Python、NumPy、SciPy、Pillow；使用方式见脚本 --help。

原始667×1000街景的高斯基准 PSNR43.45dB、SSIM0.9755，未达100%一致。这是重建指标，不是新构图的真实感分数。
