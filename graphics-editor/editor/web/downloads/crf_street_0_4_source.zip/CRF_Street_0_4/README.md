# CRF Street 0.4 · 函数编辑器

这是基于给定街景照片的可操作研究原型：像素扫描、语义对象、高斯核、父子结构、相对光照、时间轨迹与像素验收位于同一条可编辑路径。浏览器运行原生 HTML/CSS/JavaScript，不依赖 Blender、Three.js 或外部模型服务。

## 打开与操作

在线版直接打开项目主页。离线版打开 `crf_street_0_4_offline.html`，无需启动服务；它包含场景观测数据与独立参考校验图。工程的 `dist/index.html` 推荐由静态 HTTP 服务打开，以便加载参考图与交付清单。

选择左侧对象，或在画布点击物体，再修改右侧颜色、位置、比例、深度。父对象的几何修改会带动附属物。页面提供撤销、重做、恢复、原视角及其他视角、相对光照、时间轴、PNG/WebM/JSON 导出与 JSON 操作面板。具体使用和公开 API 见 [EDITOR.md](docs/EDITOR.md)。

“精确观察”用于原分辨率、原相机的 RGB 回放；“交互”使用较宽高斯核并可降低采样密度。相机、颜色、光照变化后与原照片不再完全一致是预期结果。浏览器中的像素验收从实际输出缓冲区读取，并独立解码原始 PNG。

## 完整重跑

浏览器运行无需 npm 依赖。以下 Node 依赖只用于 PNG 输出与独立检查；Python 依赖用于像素扫描及冻结检查器。

```sh
npm install --ignore-scripts
python -m pip install -r requirements.txt
python scripts/scan_scene.py
npm test
npm run verify
npm run render:stills
python scripts/pixel_gate.py
npm run render:frames
ffmpeg -y -framerate 24 -i build/frames/%04d.png -vf 'pad=ceil(iw/2)*2:ceil(ih/2)*2' -c:v libx264 -crf 18 -pix_fmt yuv420p -movflags +faststart dist/downloads/crf_street_0_4_3s.mp4
```

静态导出和视频调用同一 `crf-core.js`。视频为 72 帧、24 fps、3 秒。原帧 667×1000；H.264 4:2:0 编码在最右补一列黑像素成为 668×1000，不缩放 667 个源图列。视频采用有损编码，不用于静态 RGB8 完全相等验收。

`dist/verify.html` 是可重复运行的浏览器验收入口。它显示实际后端、像素结果、局部编辑隔离与对象拾取。WebGL 2 浮点混合不可用时自动使用共享 CPU 核心；不要把 CPU 回退测得的结果写成 GPU 性能。

## 项目结构

| 路径 | 内容 |
|---|---|
| `dist/crf-core.js` | 纯函数状态、对象、关系、轨迹与 CPU 高斯渲染 |
| `dist/crf-renderer.js` | WebGL 2 高斯累积及能力不足时的 CPU 回退 |
| `dist/crf-video.js` | WebCodecs 逐帧编码与纯 JavaScript WebM 封装 |
| `dist/editor.js` | 对象编辑、命令、导出与验收 UI |
| `dist/assets/scene-data.js` | 稠密 RGB 系数、标签、推断层与场景元数据 |
| `scanner/` | 扫描、Street 场景辅助标签和独立数组检查 |
| `scripts/` | 可重跑的扫描、渲染、验证与交付打包 |
| `verification/` | 从 0.3 原样冻结的 RGB8 检查器 |
| `tests/` | 核函数、结构、时间与事务行为测试 |
| `reports/` | 真实运行产生的验收与渲染记录 |
| `docs/` | 技术定义、操作契约、限制和研究出处 |

## 研究边界

0.4 允许保留每个观测像素的 RGB 系数，与 0.3 禁止稠密图像载荷的实验条件不同。原视角的 100% 回放若通过，只证明本版的稠密观测表示和渲染正确，不证明压缩、物体通用学习或真实三维恢复。

其他视角来自单图假设深度的 2.5D 重投影；遮挡背景是带标记的推断。光照是对观测辐射的相对调整，原照片阴影不会自动被物理重算。注册的原型包括五种基本几何，不等于任意语义物品生成。内置中文命令是有限语法；外部 LLM 应通过验证过的 JSON 操作接入。

完整论证见 [CRF_MODEL.md](docs/CRF_MODEL.md)，引擎接口见 [ENGINE.md](docs/ENGINE.md)，模型操作协议见 [LLM_OPERATIONS.md](docs/LLM_OPERATIONS.md)，交付实测结果见 `dist/downloads/CRF_Street_0_4_Report.md`。
